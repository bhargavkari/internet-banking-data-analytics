# Internet Banking Data Analysis Project

**Portfolio focus:** SQL, Excel and Power BI (with Python as supporting analysis).

## Project overview
This project models an internet-banking platform and analyzes customer activity, transfers, bill payments, vendor performance, loan demand and platform sessions. The database contains relational tables with primary/foreign keys, constraints, sample records, views, stored procedures, triggers and indexes.

## Repository structure

- `FINAL_SQL/01_database_setup.sql` — creates the `internet_banking` database, tables, database objects and sample data.
- `FINAL_SQL/02_original_python_analysis.ipynb` — original Python analysis notebook supplied with the project.
- `FINAL_SQL/03_data_analyst_queries.sql` — focused SQL portfolio query pack for operational and business KPIs.
- `FINAL_SQL/Project_Report.docx` — original project report.
- `docs/EXCEL_POWERBI_GUIDE.md` — instructions for Excel analysis and Power BI dashboard development.

## Tools
MySQL 8.0+, MySQL Workbench, Microsoft Excel, Power BI Desktop, Python (optional supporting analysis).

## How to run
1. Install/start MySQL 8.0+ and open MySQL Workbench.
2. Open and execute `FINAL_SQL/01_database_setup.sql` from top to bottom.
3. Confirm that the `internet_banking` schema and its tables are created.
4. Open and execute `FINAL_SQL/03_data_analyst_queries.sql` query by query.
5. Export result sets from Workbench as CSV for Excel or Power BI. Use the guide in `docs/EXCEL_POWERBI_GUIDE.md`.

> The SQL setup file includes demo records and is intended for a local learning environment, not production banking. Back up any existing schema before running a script that creates/repopulates database objects.

## Suggested business questions
- Which billers have the highest payment volume and successful payment value?
- What is the bill-payment success rate, overall and by biller?
- How do payment attempts and successful value change month by month?
- What share of transfers succeed or fail?
- Which customers are most active across transfers and bill payments?
- How many loan requests are pending, approved or rejected?
- Which customers may need re-engagement?

## Important note
The project contains sample data. Treat findings as analysis of the supplied sample records, not real-world banking performance. Validate the sample data and SQL results in your MySQL version before presenting numeric conclusions.
