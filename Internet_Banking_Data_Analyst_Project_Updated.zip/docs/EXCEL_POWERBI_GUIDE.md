# Excel and Power BI Portfolio Guide

The SQL project is the source of truth. Export the result sets from `03_data_analyst_queries.sql` to CSV using MySQL Workbench, then import those CSV files into Excel or Power BI.

## Excel workflow
1. Export query 1 (overall bill-payment KPIs), query 2 (biller performance), query 3 (monthly trend), query 4 (transfer summary), query 5 (customer status), and query 7 (loan pipeline) as separate CSV files.
2. In Excel, use **Data → From Text/CSV** to import each file. Choose **Transform Data** to check data types and remove blank rows if present.
3. Format dates as dates, counts as whole numbers, success rates as percentages, and monetary values as currency/decimal values.
4. Create PivotTables for biller performance, monthly payment trends, transfer status and loan status.
5. Add PivotCharts and slicers where useful. Suggested KPIs: payment attempts, successful payments, failed payments, success rate and successful payment value.
6. Use `TRIM` only on text columns where leading/trailing spaces are found; do not apply it to numeric/date columns.

## Power BI dashboard blueprint

### Page 1 — Executive Overview
- KPI cards: Total Payment Attempts, Successful Payments, Failed Payments, Success Rate %, Successful Payment Value.
- Line chart: Successful Payment Value by Month.
- Bar chart: Payment Attempts by Biller.
- Donut chart: Successful vs Failed Payments.

### Page 2 — Biller Performance
- Matrix: Biller, Attempts, Successes, Failures, Success Rate %, Successful Revenue.
- Bar chart: Success Rate by Biller.
- Add a 95% target line only if you clearly label it as a proposed benchmark, not a measured fact from the dataset.

### Page 3 — Customer & Operations
- Customer status distribution.
- Successful transfers and bill payments by customer.
- Session count by access channel.
- Inactive customer list for follow-up analysis.

### Page 4 — Loan Analysis
- Loan request count and requested amount by status.
- Monthly loan request trend.
- Average requested amount by loan type (if populated in the data).

## Suggested Power BI measures
Use the imported query outputs as tables. If you import raw bill-payment records instead, create measures such as:

```DAX
Payment Attempts = COUNTROWS(BillPayments)
Successful Payments = CALCULATE(COUNTROWS(BillPayments), BillPayments[status] = "SUCCESS")
Failed Payments = CALCULATE(COUNTROWS(BillPayments), BillPayments[status] = "FAILED")
Payment Success Rate = DIVIDE([Successful Payments], [Payment Attempts], 0)
Successful Payment Value = CALCULATE(SUM(BillPayments[amount]), BillPayments[status] = "SUCCESS")
```

Rename `BillPayments` and column names to match the names in your Power BI model. Format `Payment Success Rate` as Percentage.

## Portfolio evidence to add after you build it
- 3–4 dashboard screenshots.
- A short paragraph describing the business questions and findings from the actual query results.
- The `.pbix` file, if you are comfortable sharing it and it contains no credentials or sensitive data.

Do not claim findings or dashboard completion until you have run the queries and built the report.
