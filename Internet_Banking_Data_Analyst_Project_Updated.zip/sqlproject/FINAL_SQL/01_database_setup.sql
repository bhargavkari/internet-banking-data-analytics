CREATE DATABASE internet_banking;

USE internet_banking;
/*----Table Creation-----*/

CREATE TABLE ib_limit_profiles
(
    profile_id INT AUTO_INCREMENT PRIMARY KEY,
    profile_name VARCHAR(60) NOT NULL UNIQUE,
    description VARCHAR(255),
    is_active TINYINT(1) DEFAULT 1,
    created_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(25),
    modified_date DATETIME,
    modified_by VARCHAR(25)
);

CREATE TABLE ib_txn_types
(
    t_type_id INT AUTO_INCREMENT PRIMARY KEY,
    txn_type VARCHAR(50) NOT NULL UNIQUE,
    description VARCHAR(255),
    allowed_on_holiday TINYINT(1) DEFAULT 0,
    start_time DATETIME,
    end_time DATETIME,
    created_by VARCHAR(25),
    created_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    modified_by VARCHAR(25),
    modified_date DATETIME
);

CREATE TABLE ib_admin_users
(
    admin_id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(80) NOT NULL,
    last_name VARCHAR(80) NOT NULL,
    email VARCHAR(60) NOT NULL UNIQUE,
    role VARCHAR(60) NOT NULL,
    permissions JSON,
    password_encrypted VARCHAR(255) NOT NULL,
    is_active TINYINT(1) DEFAULT 1,
    last_login DATETIME,
    created_by VARCHAR(25),
    created_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    modified_by VARCHAR(25),
    modified_date DATETIME
);

CREATE TABLE ib_limit_definitions
(
    definition_id INT AUTO_INCREMENT PRIMARY KEY,
    profile_id INT NOT NULL,
    t_type_id INT NOT NULL,
    single_txn_limit DECIMAL(18,2) NOT NULL,
    daily_limit DECIMAL(18,2) NOT NULL,
    weekly_limit DECIMAL(18,2) NOT NULL,
    monthly_limit DECIMAL(18,2) NOT NULL,
    requires_otp TINYINT(1) DEFAULT 1,
    start_date DATETIME,
    end_date DATETIME,
    created_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(25),
    modified_by VARCHAR(25),
    modified_date DATETIME,

    CONSTRAINT fk_limit_profile FOREIGN KEY(profile_id) REFERENCES ib_limit_profiles(profile_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_limit_txn_type FOREIGN KEY(t_type_id) REFERENCES ib_txn_types(t_type_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT chk_single_limit CHECK(single_txn_limit > 0),
    CONSTRAINT chk_daily_limit CHECK(daily_limit >= single_txn_limit),
    CONSTRAINT chk_weekly_limit CHECK(weekly_limit >= daily_limit),
    CONSTRAINT chk_monthly_limit CHECK(monthly_limit >= weekly_limit),
    CONSTRAINT uq_profile_txn_type UNIQUE (profile_id, t_type_id),
    CONSTRAINT chk_date_range CHECK (end_date IS NULL OR end_date >= start_date)
);


CREATE TABLE ib_user_status (
    status_id INT AUTO_INCREMENT PRIMARY KEY,
    status_name VARCHAR(30) NOT NULL UNIQUE,
    description VARCHAR(255),
    created_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(25)
);


CREATE TABLE ib_users
(
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    bvn CHAR(11) NOT NULL UNIQUE,
    profile_id INT NOT NULL,
    username VARCHAR(60) NOT NULL UNIQUE,
    email VARCHAR(60) NOT NULL UNIQUE,
    phone_num VARCHAR(20) NOT NULL,
    status_id INT NOT NULL,
    password_encrypted VARCHAR(255) NOT NULL,
    last_login DATETIME,
    created_by VARCHAR(25),
    created_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    modified_by VARCHAR(25),
    modified_date DATETIME,
    CONSTRAINT fk_user_profile FOREIGN KEY(profile_id) REFERENCES ib_limit_profiles(profile_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_user_status FOREIGN KEY (status_id) REFERENCES ib_user_status(status_id) ON DELETE RESTRICT ON UPDATE CASCADE
);

CREATE TABLE ib_sessions
(
    session_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    session_token VARCHAR(255) NOT NULL UNIQUE,
    ip_address VARCHAR(45),
    session_meta JSON,
    login_time DATETIME NOT NULL,
    logout_time DATETIME,
    is_active TINYINT(1) DEFAULT 1,
    CONSTRAINT fk_session_user FOREIGN KEY(user_id) REFERENCES ib_users(user_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT chk_session_timeline CHECK (logout_time IS NULL OR logout_time >= login_time)
);


CREATE TABLE ib_otp_logs
(
    otp_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    otp_encrypted VARCHAR(255) NOT NULL,
    purpose VARCHAR(40),
    delivery_channel VARCHAR(60),
    expires_at DATETIME,
    verified_at DATETIME,
    is_used TINYINT(1) DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(25),
    CONSTRAINT fk_otp_user FOREIGN KEY(user_id) REFERENCES ib_users(user_id) ON DELETE RESTRICT ON UPDATE CASCADE
);


CREATE TABLE ib_beneficiaries
(
    beneficiary_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    bank_code CHAR(6) NOT NULL,
    bank_name VARCHAR(50) NOT NULL,
    account_number CHAR(10) NOT NULL,
    account_name VARCHAR(100) NOT NULL,
    nickname VARCHAR(60),
    is_active TINYINT(1) DEFAULT 1,
    created_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(25),
    modified_by VARCHAR(25),
    modified_date DATETIME,
    
    CONSTRAINT fk_beneficiary_user FOREIGN KEY(user_id) REFERENCES ib_users(user_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT uq_user_beneficiary UNIQUE (user_id, bank_code, account_number)

);

CREATE TABLE ib_transfers
(
    transfer_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    from_account CHAR(10) NOT NULL,
    to_account CHAR(10) NOT NULL,
    bank_code CHAR(6),
    amount DECIMAL(18,2) NOT NULL,
    narration VARCHAR(60),
    txn_session_id VARCHAR(40) UNIQUE,
    status VARCHAR(60),
    otp_id BIGINT,
    nibss_response TEXT,
    initiated_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    completed_time DATETIME,
    
    CONSTRAINT fk_transfer_user FOREIGN KEY(user_id) REFERENCES ib_users(user_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_transfer_otp FOREIGN KEY(otp_id) REFERENCES ib_otp_logs(otp_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT chk_transfer_amount CHECK(amount > 0),
    CONSTRAINT chk_different_accounts CHECK (from_account != to_account)
);


CREATE TABLE ib_bill_payments
(
    bill_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    from_account CHAR(10) NOT NULL,
    biller_code VARCHAR(20) NOT NULL,
    biller_name VARCHAR(100) NOT NULL,
    customer_reference VARCHAR(100),
    amount DECIMAL(18,2),
    status VARCHAR(60),
    biller_response TEXT,
    txn_reference VARCHAR(40) UNIQUE,
    initiated_time DATETIME DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_bill_user FOREIGN KEY(user_id) REFERENCES ib_users(user_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT chk_bill_amount CHECK(amount > 10)
);


CREATE TABLE ib_loan_requests
(
    request_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    loan_type VARCHAR (30),
    requested_amount DECIMAL(18,2) NOT NULL,
    tenor_months SMALLINT NOT NULL,
    purpose VARCHAR(100),
    disbursement_account CHAR(10),
    status VARCHAR(60),
    reviewed_by INT,
    decision_note TEXT,
    submitted_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    decided_at DATETIME,

    CONSTRAINT fk_loan_user FOREIGN KEY(user_id) REFERENCES ib_users(user_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_loan_admin FOREIGN KEY(reviewed_by) REFERENCES ib_admin_users(admin_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT chk_loan_amount CHECK (requested_amount > 0),
    CONSTRAINT chk_loan_tenor CHECK (tenor_months > 0)
);


CREATE TABLE ib_notifications
(
    notification_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    notif_type VARCHAR(30) NOT NULL,
    channel VARCHAR(30) NOT NULL,
    message TEXT NOT NULL,
    is_read TINYINT(1) DEFAULT 0,
    sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    related_txn_ref VARCHAR(40),

    CONSTRAINT fk_notification_user FOREIGN KEY(user_id) REFERENCES ib_users(user_id) ON DELETE RESTRICT ON UPDATE CASCADE
);

CREATE TABLE ib_audit_logs
(
    log_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    table_name VARCHAR(60) NOT NULL,
    operation VARCHAR(60) NOT NULL,
    record_id VARCHAR(100),
    performed_by INT,
    user_affected INT,
    old_values TEXT,
    new_values TEXT,
    ip_address VARCHAR(45),
    changed_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_audit_admin FOREIGN KEY(performed_by) REFERENCES ib_admin_users(admin_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_audit_user FOREIGN KEY(user_affected) REFERENCES ib_users(user_id) ON DELETE RESTRICT ON UPDATE CASCADE
);

/* ==========View Creation=========
Purpose: Aggregates transaction counts, volumes, and success rates at the individual bill utility provider level.
Reporting Use Case: Helps management identify which utility providers or bills generate the highest transaction volume. 
This is critical for negotiating commission cuts with bill aggregators. This will also help track success rate where by If a 
high-volume biller (like an electric company) drops below an 80% success rate, operations can spot it instantly and 
switch routing providers before customers flood the call centre.
*/

CREATE VIEW vw_biller_revenue_performance AS
SELECT 
    b.biller_code,
    b.biller_name,
    COUNT(b.bill_id) AS total_payment_attempts,
    SUM(CASE WHEN b.status = 'SUCCESS' THEN 1 ELSE 0 END) AS successful_payments_count,
    SUM(CASE WHEN b.status = 'FAILED' THEN 1 ELSE 0 END) AS failed_payments_count,
    ROUND((SUM(CASE WHEN b.status = 'SUCCESS' THEN 1 ELSE 0 END) / COUNT(b.bill_id)) * 100, 2) AS processing_success_rate_percentage,
    SUM(CASE WHEN b.status = 'SUCCESS' THEN b.amount ELSE 0 END) AS total_revenue_processed_value,
    AVG(CASE WHEN b.status = 'SUCCESS' THEN b.amount ELSE 0 END) AS average_ticket_size
FROM ib_bill_payments b
GROUP BY b.biller_code, b.biller_name;

/*====View 2======
Purpose:contact lIdentify inactive users on the platform 
Reporting Use Case: Help guide the business and marketing team run targeted campaigns;
- Reactivating "Never Logged In" Users:
The Situation: These customers registered but abandoned the app before their first interaction.
The Action: Send a welcoming SMS or WhatsApp message with a link to a simple "How to Get Started" video or offer immediate 
helpdesk support to clear onboarding hurdles.
- Winning Back "Slipping Away" Users:
The Situation: These users were active but haven't touched the app in 1 to 3 months. They are at high risk of leaving permanently.
The Action: Trigger an automated email highlight of convenient features, like "Did you know you can pay your electricity bills
 or save frequent beneficiaries in just one click?
- Gathering Insights from "Completely Inactive" Users:
The Situation: These users have abandoned the platform for over 90 days.
The Action: Send a short, one-question product feedback email asking, "What can we do better?" to identify system bugs, 
poor user experiences, or better offers from competitors.
*/
CREATE VIEW vw_business_inactive_users AS
SELECT 
    u.user_id,
    u.username,
    u.email,
    u.phone_num,
    u.last_login AS last_time_seen,
    
    CASE 
        WHEN u.last_login IS NULL THEN 'Registered but never logged in'
        WHEN DATEDIFF(NOW(), u.last_login) BETWEEN 30 AND 90 THEN 'Slipping away (No activity for 1 to 3 months)'
        ELSE 'Completely inactive (No activity for over 3 months)'
    END AS customer_status_bucket

FROM ib_users u
WHERE u.last_login IS NULL OR DATEDIFF(NOW(), u.last_login) >= 30;

/* ============Stored Procedures=============
Purpose: Locks a customer profile.
Business Value: to be used during fraud investigations, security incidents and account compromise.
*/

DELIMITER $$
CREATE PROCEDURE sp_lock_user
(
    IN p_user_id INT
)
BEGIN
    -- Updates the user profile to link to the 'LOCKED' status ID dynamically
    UPDATE ib_users
    SET status_id = (SELECT status_id FROM ib_user_status WHERE status_name = 'LOCKED' LIMIT 1)
    WHERE user_id = p_user_id;

END$$
DELIMITER ;

/*
Stored procedure 2
Purpose:Creation of a new beneficiary record with an immediate, corresponding transaction security alert (ib_notifications).
Business Value: Immediate fraud detection, customers getting notified that a new beneficiary record has been added to their 
profile would allow for them to raise an alarm if it was an fradulent addition. 
*/
DELIMITER $$

CREATE PROCEDURE sp_add_beneficiary_with_alert
(
    IN p_user_id INT,
    IN p_bank_code CHAR(6),
    IN p_bank_name VARCHAR(50),
    IN p_account_number CHAR(10),
    IN p_account_name VARCHAR(100),
    IN p_nickname VARCHAR(60)
)
BEGIN
    -- 1. First Action: Insert the new account into the customer's address book
    INSERT INTO ib_beneficiaries (
        user_id, bank_code, bank_name, account_number, account_name, nickname
    ) 
    VALUES (
        p_user_id, p_bank_code, p_bank_name, p_account_number, p_account_name, p_nickname
    );

    -- 2. Second Action: Automatically generate an audit/security alert in the notifications table
    INSERT INTO ib_notifications (
        user_id, notif_type, channel, message, is_read
    )
    VALUES (
        p_user_id,
        'SECURITY_ALERT',
        'IN_APP',
        CONCAT('Security Notice: A new beneficiary (', p_account_name, ' - ', p_bank_name, ') has been added to your profile.'),
        0
    );

END$$

DELIMITER ;

DELIMITER $$

/*==================TRIGGERS===================
=============First trigger==============
System Logic: Single-Session Cleanup Lifecycle: In internet banking, when users close an app tab without logging out, 
their previous session row stays open (is_active = 1). This trigger automatically sanitizes the data layer. The moment a 
new row is requested for that user_id, it updates all old rows to deactivated status (is_active=0) right before inserting the new session.
*/

DELIMITER $$

CREATE TRIGGER tr_close_previous_sessions
BEFORE INSERT ON ib_sessions
FOR EACH ROW
BEGIN
    -- Automatically find any older active sessions for this user and close them out
    UPDATE ib_sessions
    SET is_active = 0, logout_time = NOW()
    WHERE user_id = NEW.user_id AND is_active = 1;
END$$

DELIMITER ;

/*=============SECOND TRIGGER============
System Logic: This trigger intercepts every new transaction before insertion to check if an identical transfer
(same user, recipient, bank, and amount) occurred within the last 60 seconds. It would ignore past failed attempts, 
focusing strictly on blocking active or pending duplicates to prevent accidental double-debiting. If a matching transaction is 
detected, the database immediately terminates the operation and throws a system error to protect the user's funds.
*/
DELIMITER $$

CREATE TRIGGER tr_block_duplicate_transfers
BEFORE INSERT ON ib_transfers
FOR EACH ROW
BEGIN
    DECLARE v_duplicate_exists INT DEFAULT 0;

    -- Look for any identical transfer by the same user within the last 1 minute
    SELECT COUNT(*) INTO v_duplicate_exists
    FROM ib_transfers
    WHERE user_id = NEW.user_id
      AND to_account = NEW.to_account
      AND amount = NEW.amount
      AND bank_code = NEW.bank_code
      AND status != 'FAILED'  -- Ignore past failures; only block pending/successful duplicates
      AND initiated_time >= NOW() - INTERVAL 1 MINUTE
    LIMIT 1;

    -- If a matching row is found, crash the insert statement with a clean error message
    IF v_duplicate_exists > 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Transaction rejected: Duplicate transfer detected within 1 minute.';
    END IF;

END$$

DELIMITER ;

/*=============INDEX CREATION===========
======Index 1===========
Reason for creation: Optimizes high-frequency authentication, customer support lookups, and daily automated user inactive batch scans
supporting the view earlier created.
Supported Query Pattern: Searching for customer and login history criteria 
(e.g., WHERE email = ?, WHERE phone_num = ?, or WHERE last_login <= ?). 
*/
CREATE INDEX idx_users_frequent_lookup ON ib_users (email, phone_num, last_login);


/*=======Index 2===============
Reason for creation: Eliminates expensive table scans when corporate or finance team monitors third-party utility aggregator stability 
and negotiates vendor commission payouts.
Supported Query Pattern: Heavy aggregations, grouping structures, and success/failure metric filtering across specific provider 
networks (e.g., WHERE status = 'SUCCESS' GROUP BY biller_code).
*/
CREATE INDEX idx_bill_payments_frequent_scan ON ib_bill_payments (biller_code, status, amount);

/*=========Index 3==============
Reason for Creation: Maximizes search performance for the fraud operations desk when investigating potential customer 
account takeovers, ensuring a full history of profile updates loads instantly.
Supported Query Pattern: High-priority, single-customer security timeline lookups (e.g., WHERE user_affected = ?)
*/
CREATE INDEX idx_audit_user_forensics ON ib_audit_logs (user_affected);



/*=================DML - MASTER DATA INSERTS=================

Purpose:
Populate reference tables required by the Internet Banking platform.

These records provide:
- Customer limit profiles
- Transaction types
- User statuses
- Administrative users

These tables must be populated first because they are referenced
by multiple foreign keys throughout the database.

===========================================================*/

INSERT INTO ib_limit_profiles
(profile_name, description, created_by)
VALUES
('Retail','Individual retail banking customers','SYSTEM'),
('SME','Small and Medium Enterprise customers','SYSTEM'),
('Corporate','Large corporate organizations','SYSTEM'),
('Premier','High net-worth banking customers','SYSTEM');


INSERT INTO ib_txn_types
(txn_type, description, allowed_on_holiday, created_by)
VALUES
('Transfer','Interbank and intrabank transfers',1,'SYSTEM'),
('Bill Payment','Utility and merchant bill payments',1,'SYSTEM'),
('Airtime Purchase','Mobile airtime top-up',1,'SYSTEM'),
('Data Purchase','Mobile data subscription purchase',1,'SYSTEM'),
('Loan Repayment','Loan repayment transactions',0,'SYSTEM');


INSERT INTO ib_user_status
(status_name, description, created_by)
VALUES
('ACTIVE','User account is active and operational','SYSTEM'),
('LOCKED','User account is temporarily locked','SYSTEM'),
('DORMANT','User account has been inactive for a prolonged period','SYSTEM'),
('SUSPENDED','User account has been suspended for compliance review','SYSTEM');


INSERT INTO ib_admin_users
(
first_name,
last_name,
email,
role,
permissions,
password_encrypted,
is_active,
created_by
)
VALUES
(
'Amina',
'Bello',
'amina.bello@bankng.com',
'SuperAdmin',
'{"manage_users": true, "approve_loans": true, "view_audit_logs": true}',
'SHA2_PASSWORD_HASH',
1,
'SYSTEM'
),
(
'Chinedu',
'Okafor',
'chinedu.okafor@bankng.com',
'CreditOfficer',
'{"approve_loans": true, "view_users": true}',
'SHA2_PASSWORD_HASH',
1,
'SYSTEM'
),
(
'Fatima',
'Musa',
'fatima.musa@bankng.com',
'SupportAgent',
'{"reset_passwords": true, "view_users": true}',
'SHA2_PASSWORD_HASH',
1,
'SYSTEM'
),
(
'Ibrahim',
'Yusuf',
'ibrahim.yusuf@bankng.com',
'OperationsManager',
'{"manage_limits": true, "view_reports": true}',
'SHA2_PASSWORD_HASH',
1,
'SYSTEM'
),
(
'Ngozi',
'Adeyemi',
'ngozi.adeyemi@bankng.com',
'AuditOfficer',
'{"view_audit_logs": true, "generate_reports": true}',
'SHA2_PASSWORD_HASH',
1,
'SYSTEM'
);


/*=================VALIDATION QUERY=================

Purpose:
Verify that all master data records were successfully inserted
into their respective reference tables.

Expected Results:
ib_limit_profiles = 4
ib_txn_types = 5
ib_user_status = 4
ib_admin_users = 5

===================================================*/

SELECT 'ib_limit_profiles' AS table_name, COUNT(*) AS total_records
FROM ib_limit_profiles

UNION ALL

SELECT 'ib_txn_types', COUNT(*)
FROM ib_txn_types

UNION ALL

SELECT 'ib_user_status', COUNT(*)
FROM ib_user_status

UNION ALL

SELECT 'ib_admin_users', COUNT(*)
FROM ib_admin_users;


/*=================DML - LIMIT DEFINITIONS=================

Purpose:
Populate transaction limits for each customer profile
and transaction type combination.

This bridge table resolves the many-to-many relationship
between ib_limit_profiles and ib_txn_types.

The limits reflect realistic Internet Banking controls
commonly applied by Nigerian financial institutions.

=========================================================*/

INSERT INTO ib_limit_definitions
(
profile_id,
t_type_id,
single_txn_limit,
daily_limit,
weekly_limit,
monthly_limit,
requires_otp,
created_by
)
VALUES

-- Retail
(1,1,1000000,5000000,15000000,50000000,1,'SYSTEM'),
(1,2,500000,2000000,6000000,20000000,1,'SYSTEM'),
(1,3,50000,200000,600000,2000000,0,'SYSTEM'),
(1,4,100000,300000,1000000,3000000,0,'SYSTEM'),
(1,5,500000,1000000,3000000,10000000,1,'SYSTEM'),

-- SME
(2,1,5000000,20000000,60000000,200000000,1,'SYSTEM'),
(2,2,2000000,10000000,30000000,100000000,1,'SYSTEM'),
(2,3,100000,500000,1500000,5000000,0,'SYSTEM'),
(2,4,200000,800000,2500000,8000000,0,'SYSTEM'),
(2,5,2000000,5000000,15000000,50000000,1,'SYSTEM'),

-- Corporate
(3,1,50000000,200000000,600000000,2000000000,1,'SYSTEM'),
(3,2,10000000,50000000,150000000,500000000,1,'SYSTEM'),
(3,3,500000,2000000,6000000,20000000,0,'SYSTEM'),
(3,4,500000,2000000,6000000,20000000,0,'SYSTEM'),
(3,5,10000000,30000000,100000000,300000000,1,'SYSTEM'),

-- Premier
(4,1,10000000,50000000,150000000,500000000,1,'SYSTEM'),
(4,2,5000000,20000000,60000000,200000000,1,'SYSTEM'),
(4,3,200000,1000000,3000000,10000000,0,'SYSTEM'),
(4,4,200000,1000000,3000000,10000000,0,'SYSTEM'),
(4,5,5000000,10000000,30000000,100000000,1,'SYSTEM');

/*=================VALIDATION QUERY=================

Purpose:
Verify that all profile and transaction type
combinations were successfully loaded into
the bridge table.

Expected Result:
20 records

===================================================*/

SELECT
'ib_limit_definitions' AS table_name,
COUNT(*) AS total_records
FROM ib_limit_definitions;


/*=================DML - INTERNET BANKING USERS=================

Purpose:
Populate Internet Banking customer accounts.

These users represent different customer categories
including Retail, SME, Corporate, and Premier customers.

The dataset includes a realistic distribution of
account statuses to support future analytical,
operational, and machine learning queries.

==============================================================*/

INSERT INTO ib_users
(
bvn,
profile_id,
username,
email,
phone_num,
status_id,
password_encrypted,
created_by
)
VALUES
('22145678901',1,'adebayo01','adebayo01@gmail.com','08030000001',1,'HASHED_PASSWORD','SYSTEM'),
('22145678902',1,'chioma02','chioma02@gmail.com','08030000002',1,'HASHED_PASSWORD','SYSTEM'),
('22145678903',1,'emeka03','emeka03@gmail.com','08030000003',1,'HASHED_PASSWORD','SYSTEM'),
('22145678904',1,'fatima04','fatima04@gmail.com','08030000004',1,'HASHED_PASSWORD','SYSTEM'),
('22145678905',1,'ibrahim05','ibrahim05@gmail.com','08030000005',1,'HASHED_PASSWORD','SYSTEM'),
('22145678906',1,'ngozi06','ngozi06@gmail.com','08030000006',1,'HASHED_PASSWORD','SYSTEM'),
('22145678907',1,'oluwaseun07','oluwaseun07@gmail.com','08030000007',1,'HASHED_PASSWORD','SYSTEM'),
('22145678908',1,'amina08','amina08@gmail.com','08030000008',2,'HASHED_PASSWORD','SYSTEM'),
('22145678909',1,'yakubu09','yakubu09@gmail.com','08030000009',3,'HASHED_PASSWORD','SYSTEM'),
('22145678910',1,'zainab10','zainab10@gmail.com','08030000010',4,'HASHED_PASSWORD','SYSTEM');

-- Retail Users (11-20)

INSERT INTO ib_users
(
bvn,
profile_id,
username,
email,
phone_num,
status_id,
password_encrypted,
created_by
)
VALUES
('22145678911',1,'tunde11','tunde11@gmail.com','08030000011',1,'HASHED_PASSWORD','SYSTEM'),
('22145678912',1,'kemi12','kemi12@gmail.com','08030000012',1,'HASHED_PASSWORD','SYSTEM'),
('22145678913',1,'uche13','uche13@gmail.com','08030000013',1,'HASHED_PASSWORD','SYSTEM'),
('22145678914',1,'halima14','halima14@gmail.com','08030000014',1,'HASHED_PASSWORD','SYSTEM'),
('22145678915',1,'segun15','segun15@gmail.com','08030000015',1,'HASHED_PASSWORD','SYSTEM'),
('22145678916',1,'blessing16','blessing16@gmail.com','08030000016',1,'HASHED_PASSWORD','SYSTEM'),
('22145678917',1,'ifeanyi17','ifeanyi17@gmail.com','08030000017',1,'HASHED_PASSWORD','SYSTEM'),
('22145678918',1,'mary18','mary18@gmail.com','08030000018',2,'HASHED_PASSWORD','SYSTEM'),
('22145678919',1,'samuel19','samuel19@gmail.com','08030000019',3,'HASHED_PASSWORD','SYSTEM'),
('22145678920',1,'joy20','joy20@gmail.com','08030000020',1,'HASHED_PASSWORD','SYSTEM');

-- SME Users (21-30)

INSERT INTO ib_users
(
bvn,
profile_id,
username,
email,
phone_num,
status_id,
password_encrypted,
created_by
)
VALUES
('22145678921',2,'alphafoods','contact@alphafoods.ng','08030000021',1,'HASHED_PASSWORD','SYSTEM'),
('22145678922',2,'betatraders','info@betatraders.ng','08030000022',1,'HASHED_PASSWORD','SYSTEM'),
('22145678923',2,'crestfarms','admin@crestfarms.ng','08030000023',1,'HASHED_PASSWORD','SYSTEM'),
('22145678924',2,'deltasupplies','office@deltasupplies.ng','08030000024',1,'HASHED_PASSWORD','SYSTEM'),
('22145678925',2,'eagleventures','support@eagleventures.ng','08030000025',1,'HASHED_PASSWORD','SYSTEM'),
('22145678926',2,'futuretech','hello@futuretech.ng','08030000026',1,'HASHED_PASSWORD','SYSTEM'),
('22145678927',2,'greenenergy','contact@greenenergy.ng','08030000027',1,'HASHED_PASSWORD','SYSTEM'),
('22145678928',2,'horizonlogistics','admin@horizonlogistics.ng','08030000028',2,'HASHED_PASSWORD','SYSTEM'),
('22145678929',2,'idealmedia','info@idealmedia.ng','08030000029',4,'HASHED_PASSWORD','SYSTEM'),
('22145678930',2,'jubileeholdings','office@jubileeholdings.ng','08030000030',1,'HASHED_PASSWORD','SYSTEM');

-- Corporate Users (31-35)

INSERT INTO ib_users
(
bvn,
profile_id,
username,
email,
phone_num,
status_id,
password_encrypted,
created_by
)
VALUES
('22145678931',3,'zenithgroup','finance@zenithgroup.ng','08030000031',1,'HASHED_PASSWORD','SYSTEM'),
('22145678932',3,'africomglobal','treasury@africomglobal.ng','08030000032',1,'HASHED_PASSWORD','SYSTEM'),
('22145678933',3,'unitedindustries','accounts@unitedindustries.ng','08030000033',1,'HASHED_PASSWORD','SYSTEM'),
('22145678934',3,'megacorp','finance@megacorp.ng','08030000034',3,'HASHED_PASSWORD','SYSTEM'),
('22145678935',3,'primeholdings','treasury@primeholdings.ng','08030000035',1,'HASHED_PASSWORD','SYSTEM');

-- Premier Users (36-40)

INSERT INTO ib_users
(
bvn,
profile_id,
username,
email,
phone_num,
status_id,
password_encrypted,
created_by
)
VALUES
('22145678936',4,'adekunle36','adekunle36@gmail.com','08030000036',1,'HASHED_PASSWORD','SYSTEM'),
('22145678937',4,'folake37','folake37@gmail.com','08030000037',1,'HASHED_PASSWORD','SYSTEM'),
('22145678938',4,'olumide38','olumide38@gmail.com','08030000038',1,'HASHED_PASSWORD','SYSTEM'),
('22145678939',4,'hadiza39','hadiza39@gmail.com','08030000039',4,'HASHED_PASSWORD','SYSTEM'),
('22145678940',4,'chukwu40','chukwu40@gmail.com','08030000040',1,'HASHED_PASSWORD','SYSTEM');

/*=================VALIDATION QUERY=================

Purpose:
Verify that all Internet Banking customer accounts
were successfully loaded.

Expected Result:
40 records

===================================================*/

SELECT
'ib_users' AS table_name,
COUNT(*) AS total_records
FROM ib_users;

/*=================DML - INTERNET BANKING SESSIONS=================

Purpose:
Populate Internet Banking login session records.

Session records capture customer login activity,
IP addresses, device information, and session context
stored as JSON data.

These records support operational monitoring,
security analysis, customer behavior analytics,
and future machine learning datasets.

==============================================================*/

DROP TRIGGER IF EXISTS tr_close_previous_sessions;

INSERT INTO ib_sessions
(
user_id,
session_token,
ip_address,
session_meta,
login_time,
logout_time,
is_active
)
VALUES

(1,'SESS10001','102.89.10.15',
'{"browser":"Chrome","device":"Windows Laptop","location":"Lagos"}',
'2026-03-12 08:15:00',
'2026-03-12 09:02:00',
0),

(2,'SESS10002','102.89.10.16',
'{"browser":"Edge","device":"Desktop","location":"Abuja"}',
'2026-03-14 10:25:00',
'2026-03-14 11:10:00',
0),

(3,'SESS10003','102.89.10.17',
'{"browser":"Chrome","device":"Android Phone","location":"Port Harcourt"}',
'2026-03-18 07:40:00',
'2026-03-18 08:12:00',
0),

(4,'SESS10004','102.89.10.18',
'{"browser":"Safari","device":"iPhone","location":"Lagos"}',
'2026-03-22 18:10:00',
'2026-03-22 18:45:00',
0),

(5,'SESS10005','102.89.10.19',
'{"browser":"Chrome","device":"MacBook","location":"Kano"}',
'2026-03-25 12:20:00',
'2026-03-25 13:05:00',
0),

(6,'SESS10006','102.89.10.20',
'{"browser":"Firefox","device":"Desktop","location":"Ibadan"}',
'2026-04-02 09:05:00',
'2026-04-02 09:50:00',
0),

(7,'SESS10007','102.89.10.21',
'{"browser":"Chrome","device":"Android Phone","location":"Kaduna"}',
'2026-04-04 16:40:00',
'2026-04-04 17:25:00',
0),

(8,'SESS10008','102.89.10.22',
'{"browser":"Edge","device":"Laptop","location":"Lagos"}',
'2026-04-06 11:00:00',
'2026-04-06 11:38:00',
0),

(9,'SESS10009','102.89.10.23',
'{"browser":"Chrome","device":"Android Phone","location":"Enugu"}',
'2026-04-09 07:15:00',
'2026-04-09 07:55:00',
0),

(10,'SESS10010','102.89.10.24',
'{"browser":"Safari","device":"iPhone","location":"Abuja"}',
'2026-04-11 20:05:00',
'2026-04-11 20:41:00',
0),

(11,'SESS10011','102.89.10.25',
'{"browser":"Chrome","device":"Windows Laptop","location":"Lagos"}',
'2026-04-15 08:00:00',
'2026-04-15 08:44:00',
0),

(12,'SESS10012','102.89.10.26',
'{"browser":"Edge","device":"Desktop","location":"Ibadan"}',
'2026-04-18 10:35:00',
'2026-04-18 11:15:00',
0),

(13,'SESS10013','102.89.10.27',
'{"browser":"Firefox","device":"Laptop","location":"Kano"}',
'2026-04-22 13:10:00',
'2026-04-22 13:58:00',
0),

(14,'SESS10014','102.89.10.28',
'{"browser":"Chrome","device":"Android Phone","location":"Abuja"}',
'2026-04-25 15:25:00',
'2026-04-25 16:05:00',
0),

(15,'SESS10015','102.89.10.29',
'{"browser":"Safari","device":"iPhone","location":"Port Harcourt"}',
'2026-05-01 09:15:00',
'2026-05-01 09:48:00',
0),

(16,'SESS10016','102.89.10.30',
'{"browser":"Chrome","device":"Windows Laptop","location":"Lagos"}',
'2026-05-05 11:40:00',
'2026-05-05 12:26:00',
0),

(17,'SESS10017','102.89.10.31',
'{"browser":"Edge","device":"Desktop","location":"Kaduna"}',
'2026-05-10 17:00:00',
'2026-05-10 17:50:00',
0),

(18,'SESS10018','102.89.10.32',
'{"browser":"Chrome","device":"Android Phone","location":"Benin City"}',
'2026-05-15 08:20:00',
'2026-05-15 09:05:00',
0),

(19,'SESS10019','102.89.10.33',
'{"browser":"Firefox","device":"Laptop","location":"Lagos"}',
'2026-05-20 14:30:00',
'2026-05-20 15:12:00',
0),

(20,'SESS10020','102.89.10.34',
'{"browser":"Chrome","device":"Windows Laptop","location":"Abuja"}',
'2026-05-25 19:00:00',
'2026-05-25 19:42:00',
0);

INSERT INTO ib_sessions
(
user_id,
session_token,
ip_address,
session_meta,
login_time,
logout_time,
is_active
)
VALUES

(21,'SESS10021','102.89.10.35',
'{"browser":"Chrome","device":"Business Laptop","location":"Lagos"}',
'2026-05-28 08:10:00',
'2026-05-28 09:00:00',
0),

(22,'SESS10022','102.89.10.36',
'{"browser":"Edge","device":"Desktop","location":"Abuja"}',
'2026-05-30 10:25:00',
'2026-05-30 11:05:00',
0),

(23,'SESS10023','102.89.10.37',
'{"browser":"Chrome","device":"Android Phone","location":"Enugu"}',
'2026-06-01 07:30:00',
'2026-06-01 08:12:00',
0),

(24,'SESS10024','102.89.10.38',
'{"browser":"Safari","device":"iPhone","location":"Port Harcourt"}',
'2026-06-02 12:10:00',
'2026-06-02 12:55:00',
0),

(25,'SESS10025','102.89.10.39',
'{"browser":"Chrome","device":"MacBook","location":"Ibadan"}',
'2026-06-03 15:20:00',
'2026-06-03 16:10:00',
0),

(26,'SESS10026','102.89.10.40',
'{"browser":"Firefox","device":"Laptop","location":"Kaduna"}',
'2026-06-04 09:15:00',
'2026-06-04 10:00:00',
0),

(27,'SESS10027','102.89.10.41',
'{"browser":"Chrome","device":"Android Phone","location":"Lagos"}',
'2026-06-05 18:05:00',
'2026-06-05 18:52:00',
0),

(28,'SESS10028','102.89.10.42',
'{"browser":"Edge","device":"Desktop","location":"Abuja"}',
'2026-06-06 11:25:00',
'2026-06-06 12:10:00',
0),

(29,'SESS10029','102.89.10.43',
'{"browser":"Chrome","device":"Business Laptop","location":"Kano"}',
'2026-06-07 08:00:00',
'2026-06-07 08:48:00',
0),

(30,'SESS10030','102.89.10.44',
'{"browser":"Safari","device":"iPhone","location":"Lagos"}',
'2026-06-08 19:00:00',
'2026-06-08 19:40:00',
0),

(31,'SESS10031','102.89.10.45',
'{"browser":"Chrome","device":"Corporate Desktop","location":"Abuja"}',
'2026-06-09 09:20:00',
'2026-06-09 10:15:00',
0),

(32,'SESS10032','102.89.10.46',
'{"browser":"Edge","device":"Corporate Laptop","location":"Lagos"}',
'2026-06-09 13:10:00',
'2026-06-09 14:05:00',
0),

(33,'SESS10033','102.89.10.47',
'{"browser":"Chrome","device":"Windows Laptop","location":"Port Harcourt"}',
'2026-06-10 10:05:00',
'2026-06-10 10:55:00',
0),

(34,'SESS10034','102.89.10.48',
'{"browser":"Firefox","device":"Desktop","location":"Kano"}',
'2026-06-10 15:30:00',
'2026-06-10 16:25:00',
0),

(35,'SESS10035','102.89.10.49',
'{"browser":"Chrome","device":"Business Laptop","location":"Abuja"}',
'2026-06-11 08:40:00',
'2026-06-11 09:32:00',
0),

(36,'SESS10036','102.89.10.50',
'{"browser":"Safari","device":"iPhone","location":"Lagos"}',
'2026-06-11 18:00:00',
'2026-06-11 18:38:00',
0),

(37,'SESS10037','102.89.10.51',
'{"browser":"Chrome","device":"MacBook","location":"Ibadan"}',
'2026-06-12 11:05:00',
'2026-06-12 11:55:00',
0),

(38,'SESS10038','102.89.10.52',
'{"browser":"Edge","device":"Desktop","location":"Kaduna"}',
'2026-06-12 14:15:00',
'2026-06-12 15:00:00',
0),

(39,'SESS10039','102.89.10.53',
'{"browser":"Chrome","device":"Premier Laptop","location":"Lagos"}',
'2026-06-13 09:00:00',
'2026-06-13 09:52:00',
0),

(40,'SESS10040','102.89.10.54',
'{"browser":"Safari","device":"iPhone","location":"Abuja"}',
'2026-06-13 20:10:00',
'2026-06-13 20:55:00',
0),
(1, 'SESS-TOK-001A', '102.89.22.41', '{"device": "iPhone 15", "browser": "Safari", "location": "Lagos, NG"}', '2026-06-15 08:00:00', '2026-06-15 08:15:00', 0),
(1, 'SESS-TOK-001B', '197.210.4.12', '{"device": "Ubuntu Desktop", "browser": "Firefox", "location": "Kano, NG"}', '2026-06-15 08:02:00', NULL, 1), 
-- FRAUD ANOMALY FLAG: 2 mins lapse, completely different OS & IP subnet
(9, 'SESS-TOK-009A', '102.89.99.11', '{"device": "Android Tecno", "browser": "Chrome", "location": "Ibadan, NG"}', '2026-06-15 08:01:30', NULL, 1);


/*=================VALIDATION QUERY=================

Purpose:
Verify that all Internet Banking session records
were successfully loaded.

Expected Result:
40 records

===================================================*/

SELECT
'ib_sessions' AS table_name,
COUNT(*) AS total_records
FROM ib_sessions;


/*=================DML - OTP LOGS=================

Purpose:
Populate One-Time Password (OTP) records used
for customer authentication and transaction verification.

The dataset includes successful, expired, and
unused OTP events across different delivery channels.

==============================================================*/

INSERT INTO ib_otp_logs
(
user_id,
otp_encrypted,
purpose,
delivery_channel,
expires_at,
verified_at,
is_used,
created_by
)
VALUES

(1,'OTP_HASH_001','LOGIN','SMS','2026-05-01 08:05:00','2026-05-01 08:02:00',1,'SYSTEM'),
(2,'OTP_HASH_002','LOGIN','EMAIL','2026-05-02 09:10:00','2026-05-02 09:05:00',1,'SYSTEM'),
(3,'OTP_HASH_003','TRANSFER','SMS','2026-05-03 10:15:00','2026-05-03 10:12:00',1,'SYSTEM'),
(4,'OTP_HASH_004','LOGIN','SMS','2026-05-04 11:20:00',NULL,0,'SYSTEM'),
(5,'OTP_HASH_005','BILL_PAYMENT','EMAIL','2026-05-05 12:25:00','2026-05-05 12:20:00',1,'SYSTEM'),

(6,'OTP_HASH_006','LOGIN','SMS','2026-05-06 13:30:00','2026-05-06 13:26:00',1,'SYSTEM'),
(7,'OTP_HASH_007','TRANSFER','EMAIL','2026-05-07 14:35:00',NULL,0,'SYSTEM'),
(8,'OTP_HASH_008','LOGIN','SMS','2026-05-08 15:40:00','2026-05-08 15:35:00',1,'SYSTEM'),
(9,'OTP_HASH_009','LOGIN','EMAIL','2026-05-09 16:45:00',NULL,0,'SYSTEM'),
(10,'OTP_HASH_010','LOAN_REQUEST','SMS','2026-05-10 17:50:00','2026-05-10 17:46:00',1,'SYSTEM'),

(11,'OTP_HASH_011','LOGIN','SMS','2026-05-11 08:05:00','2026-05-11 08:02:00',1,'SYSTEM'),
(12,'OTP_HASH_012','TRANSFER','EMAIL','2026-05-12 09:10:00','2026-05-12 09:06:00',1,'SYSTEM'),
(13,'OTP_HASH_013','LOGIN','SMS','2026-05-13 10:15:00',NULL,0,'SYSTEM'),
(14,'OTP_HASH_014','LOGIN','EMAIL','2026-05-14 11:20:00','2026-05-14 11:16:00',1,'SYSTEM'),
(15,'OTP_HASH_015','BILL_PAYMENT','SMS','2026-05-15 12:25:00','2026-05-15 12:20:00',1,'SYSTEM'),

(16,'OTP_HASH_016','LOGIN','EMAIL','2026-05-16 13:30:00',NULL,0,'SYSTEM'),
(17,'OTP_HASH_017','TRANSFER','SMS','2026-05-17 14:35:00','2026-05-17 14:31:00',1,'SYSTEM'),
(18,'OTP_HASH_018','LOGIN','SMS','2026-05-18 15:40:00','2026-05-18 15:36:00',1,'SYSTEM'),
(19,'OTP_HASH_019','LOGIN','EMAIL','2026-05-19 16:45:00',NULL,0,'SYSTEM'),
(20,'OTP_HASH_020','TRANSFER','SMS','2026-05-20 17:50:00','2026-05-20 17:46:00',1,'SYSTEM');

/*=================VALIDATION QUERY=================

Purpose:
Verify that all OTP records were successfully loaded.

Expected Result:
20 records

===================================================*/

SELECT
'ib_otp_logs' AS table_name,
COUNT(*) AS total_records
FROM ib_otp_logs;

/*=================DML - BENEFICIARIES=================

Purpose:
Populate saved beneficiary records used for
interbank transfers and payment transactions.

These records represent frequently used recipients
maintained by Internet Banking customers.

==============================================================*/

INSERT INTO ib_beneficiaries
(
user_id,
bank_code,
bank_name,
account_number,
account_name,
nickname,
is_active,
created_by
)
VALUES

(1,'044001','Access Bank','1000000001','John Okafor','Brother John',1,'SYSTEM'),
(2,'058001','GTBank','1000000002','Mary Eze','Mary',1,'SYSTEM'),
(3,'011001','First Bank','1000000003','David Musa','School Fees',1,'SYSTEM'),
(4,'033001','UBA','1000000004','Grace Bello','Grace',1,'SYSTEM'),
(5,'214001','FCMB','1000000005','Samuel Ade','Savings',1,'SYSTEM'),

(6,'044001','Access Bank','1000000006','Esther Ibrahim','Esther',1,'SYSTEM'),
(7,'058001','GTBank','1000000007','Peter Okon','Peter',1,'SYSTEM'),
(8,'011001','First Bank','1000000008','Ruth Daniel','Family',1,'SYSTEM'),
(9,'033001','UBA','1000000009','Michael Obi','Mike',1,'SYSTEM'),
(10,'214001','FCMB','1000000010','Sarah Yusuf','Sarah',1,'SYSTEM'),

(11,'044001','Access Bank','1000000011','Paul Emeka','Business Partner',1,'SYSTEM'),
(12,'058001','GTBank','1000000012','Joy Amina','Joy',1,'SYSTEM'),
(13,'011001','First Bank','1000000013','Daniel Uche','Landlord',1,'SYSTEM'),
(14,'033001','UBA','1000000014','Blessing Kalu','Blessing',1,'SYSTEM'),
(15,'214001','FCMB','1000000015','Ahmed Sule','Ahmed',1,'SYSTEM'),

(16,'044001','Access Bank','1000000016','Patricia Obi','Patricia',1,'SYSTEM'),
(17,'058001','GTBank','1000000017','Henry Okafor','Henry',1,'SYSTEM'),
(18,'011001','First Bank','1000000018','Rebecca James','Rebecca',1,'SYSTEM'),
(19,'033001','UBA','1000000019','Victor Eze','Victor',1,'SYSTEM'),
(20,'214001','FCMB','1000000020','Mercy Bello','Mercy',1,'SYSTEM'),

(21,'044001','Access Bank','1000000021','Alpha Foods Ltd','Vendor A',1,'SYSTEM'),
(22,'058001','GTBank','1000000022','Beta Traders Ltd','Vendor B',1,'SYSTEM'),
(23,'011001','First Bank','1000000023','Crest Farms Ltd','Farm Ops',1,'SYSTEM'),
(24,'033001','UBA','1000000024','Delta Supplies Ltd','Supplier',1,'SYSTEM'),
(25,'214001','FCMB','1000000025','Eagle Ventures Ltd','Operations',1,'SYSTEM');

/*=================VALIDATION QUERY=================

Purpose:
Verify that all beneficiary records
were successfully loaded.

Expected Result:
25 records

===================================================*/

SELECT
'ib_beneficiaries' AS table_name,
COUNT(*) AS total_records
FROM ib_beneficiaries;

/*=================DML - TRANSFERS=================

Purpose:
Populate interbank transfer transactions executed
through the Internet Banking platform.

The dataset includes successful, pending, and
failed transfer transactions linked to OTP
verification records.

==============================================================*/

INSERT INTO ib_transfers
(
user_id,
from_account,
to_account,
bank_code,
amount,
narration,
txn_session_id,
status,
otp_id,
nibss_response,
completed_time
)
VALUES

(1,'3000000001','1000000001','044001',25000,'Family Support','TXN000001','SUCCESS',1,'Approved','2026-05-01 08:10:00'),
(2,'3000000002','1000000002','058001',50000,'Rent Payment','TXN000002','SUCCESS',2,'Approved','2026-05-02 09:12:00'),
(3,'3000000003','1000000003','011001',150000,'School Fees','TXN000003','SUCCESS',3,'Approved','2026-05-03 10:20:00'),
(4,'3000000004','1000000004','033001',20000,'Gift','TXN000004','FAILED',4,'OTP Expired',NULL),
(5,'3000000005','1000000005','214001',75000,'Vendor Payment','TXN000005','SUCCESS',5,'Approved','2026-05-05 12:30:00'),

(6,'3000000006','1000000006','044001',40000,'Utilities','TXN000006','SUCCESS',6,'Approved','2026-05-06 13:35:00'),
(7,'3000000007','1000000007','058001',85000,'Transfer','TXN000007','FAILED',7,'OTP Not Verified',NULL),
(8,'3000000008','1000000008','011001',120000,'Medical Bills','TXN000008','SUCCESS',8,'Approved','2026-05-08 15:45:00'),
(9,'3000000009','1000000009','033001',35000,'Family Support','TXN000009','FAILED',9,'OTP Expired',NULL),
(10,'3000000010','1000000010','214001',60000,'Loan Settlement','TXN000010','SUCCESS',10,'Approved','2026-05-10 18:00:00'),

(11,'3000000011','1000000011','044001',45000,'Supplier Payment','TXN000011','SUCCESS',11,'Approved','2026-05-11 08:10:00'),
(12,'3000000012','1000000012','058001',90000,'Business Expense','TXN000012','SUCCESS',12,'Approved','2026-05-12 09:15:00'),
(13,'3000000013','1000000013','011001',30000,'House Rent','TXN000013','FAILED',13,'OTP Expired',NULL),
(14,'3000000014','1000000014','033001',55000,'Gift Transfer','TXN000014','SUCCESS',14,'Approved','2026-05-14 11:25:00'),
(15,'3000000015','1000000015','214001',125000,'Contract Payment','TXN000015','SUCCESS',15,'Approved','2026-05-15 12:35:00'),

(16,'3000000016','1000000016','044001',40000,'Transfer','TXN000016','FAILED',16,'OTP Not Verified',NULL),
(17,'3000000017','1000000017','058001',70000,'Family Support','TXN000017','SUCCESS',17,'Approved','2026-05-17 14:40:00'),
(18,'3000000018','1000000018','011001',50000,'Savings Contribution','TXN000018','SUCCESS',18,'Approved','2026-05-18 15:45:00'),
(19,'3000000019','1000000019','033001',25000,'Donation','TXN000019','FAILED',19,'OTP Expired',NULL),
(20,'3000000020','1000000020','214001',95000,'Business Transfer','TXN000020','SUCCESS',20,'Approved','2026-05-20 18:00:00'),

(21,'3000000021','1000000021','044001',250000,'Vendor Settlement','TXN000021','SUCCESS',NULL,'Approved','2026-05-21 10:00:00'),
(22,'3000000022','1000000022','058001',300000,'Inventory Purchase','TXN000022','SUCCESS',NULL,'Approved','2026-05-22 11:00:00'),
(23,'3000000023','1000000023','011001',180000,'Farm Operations','TXN000023','PENDING',NULL,'Awaiting Settlement',NULL),
(24,'3000000024','1000000024','033001',220000,'Supplier Payment','TXN000024','SUCCESS',NULL,'Approved','2026-05-24 13:00:00'),
(25,'3000000025','1000000025','214001',275000,'Operational Expense','TXN000025','SUCCESS',NULL,'Approved','2026-05-25 14:00:00');

/*=================VALIDATION QUERY=================

Purpose:
Verify that all transfer transactions
were successfully loaded.

Expected Result:
25 records

===================================================*/
SELECT
'ib_transfers' AS table_name,
COUNT(*) AS total_records
FROM ib_transfers;

/*=================DML - BILL PAYMENTS=================

Purpose:
Populate bill payment transactions processed
through the Internet Banking platform.

The dataset includes utility payments,
telecommunications services, cable television,
and government-related payments.

==============================================================*/

INSERT INTO ib_bill_payments
(
user_id,
from_account,
biller_code,
biller_name,
customer_reference,
amount,
status,
biller_response,
txn_reference,
initiated_time
)
VALUES

(1,'3000000001','IKEDC','Ikeja Electric','MTR001001',15000,'SUCCESS','<response><status>SUCCESS</status><provider>IKEDC</provider><message>Payment Confirmed</message></response>','BILL000001','2026-05-01 09:00:00'),
(2,'3000000002','DSTV','DSTV Nigeria','SMA001002',25000,'SUCCESS','<response><status>SUCCESS</status><provider>DSTV</provider><message>Subscription Renewed</message></response>','BILL000002','2026-05-02 10:00:00'),
(3,'3000000003','MTN','MTN Nigeria','MTN001003',5000,'SUCCESS','<response><status>SUCCESS</status><provider>MTN</provider><message>Recharge Successful</message></response>','BILL000003','2026-05-03 11:00:00'),
(4,'3000000004','AIRTEL','Airtel Nigeria','AIR001004',3000,'FAILED','<response><status>INSUFFICIENT_FUNDS</status><provider>AIRTEL</provider><message>Insufficient Funds</message></response>','BILL000004','2026-05-04 12:00:00'),
(5,'3000000005','AEDC','Abuja Electricity Distribution','MTR001005',22000,'SUCCESS','<response><status>SUCCESS</status><provider>AEDC</provider><message>Payment Confirmed</message></response>','BILL000005','2026-05-05 13:00:00'),

(6,'3000000006','GOTV','GOtv Nigeria','GTV001006',8000,'SUCCESS','<response><status>SUCCESS</status><provider>GOTV</provider><message>Subscription Renewed</message></response>','BILL000006','2026-05-06 14:00:00'),
(7,'3000000007','MTN','MTN Nigeria','MTN001007',2500,'SUCCESS','<response><status>SUCCESS</status><provider>MTN</provider><message>Recharge Successful</message></response>','BILL000007','2026-05-07 15:00:00'),
(8,'3000000008','AIRTEL','Airtel Nigeria','AIR001008',4000,'SUCCESS','<response><status>SUCCESS</status><provider>AIRTEL</provider><message>Recharge Successful</message></response>','BILL000008','2026-05-08 16:00:00'),
(9,'3000000009','WAEC','WAEC Registration','WAE001009',18000,'PENDING','<response><status>PENDING</status><provider>WAEC</provider><message>Awaiting Confirmation</message></response>','BILL000009','2026-05-09 17:00:00'),
(10,'3000000010','JAMB','JAMB Registration','JAM001010',7000,'SUCCESS','<response><status>SUCCESS</status><provider>JAMB</provider><message>Payment Confirmed</message></response>','BILL000010','2026-05-10 18:00:00'),

(11,'3000000011','PHCN','Power Utility','MTR001011',12000,'SUCCESS','<response><status>SUCCESS</status><provider>PHCN</provider><message>Payment Confirmed</message></response>','BILL000011','2026-05-11 09:00:00'),
(12,'3000000012','DSTV','DSTV Nigeria','SMA001012',30000,'SUCCESS','<response><status>SUCCESS</status><provider>DSTV</provider><message>Subscription Renewed</message></response>','BILL000012','2026-05-12 10:00:00'),
(13,'3000000013','MTN','MTN Nigeria','MTN001013',3500,'FAILED','<response><status>GATEWAY_TIMEOUT</status><provider>MTN</provider><message>Network Error</message></response>','BILL000013','2026-05-13 11:00:00'),
(14,'3000000014','AIRTEL','Airtel Nigeria','AIR001014',4500,'SUCCESS','<response><status>SUCCESS</status><provider>AIRTEL</provider><message>Recharge Successful</message></response>','BILL000014','2026-05-14 12:00:00'),
(15,'3000000015','LASG','Lagos State Government','LAS001015',50000,'SUCCESS','<response><status>SUCCESS</status><provider>LASG</provider><message>Payment Confirmed</message></response>','BILL000015','2026-05-15 13:00:00');


/*=================VALIDATION QUERY=================

Purpose:
Verify that all bill payment records
were successfully loaded.

Expected Result:
15 records

===================================================*/

SELECT
'ib_bill_payments' AS table_name,
COUNT(*) AS total_records
FROM ib_bill_payments;

/*=================DML - LOAN REQUESTS=================

Purpose:
Populate customer loan applications submitted
through the Internet Banking platform.

The dataset includes approved, rejected, and
pending requests reviewed by authorized
bank administrators.

==============================================================*/

INSERT INTO ib_loan_requests
(
user_id,
loan_type,
requested_amount,
tenor_months,
purpose,
disbursement_account,
status,
reviewed_by,
decision_note,
decided_at
)
VALUES

(1,'Personal Loan',500000,12,'Home Renovation','3000000001','APPROVED',2,'Credit assessment passed','2026-05-01 10:00:00'),
(2,'Personal Loan',250000,6,'Medical Expenses','3000000002','APPROVED',2,'Approved under retail lending policy','2026-05-02 11:00:00'),
(3,'Education Loan',750000,24,'University Tuition','3000000003','APPROVED',2,'Income verification completed','2026-05-03 12:00:00'),
(4,'Personal Loan',300000,12,'Business Support','3000000004','REJECTED',2,'Insufficient repayment capacity','2026-05-04 13:00:00'),
(5,'Asset Finance',1200000,36,'Vehicle Purchase','3000000005','APPROVED',4,'Asset valuation completed','2026-05-05 14:00:00'),

(6,'Personal Loan',400000,12,'Family Expenses','3000000006','APPROVED',2,'Customer in good standing','2026-05-06 15:00:00'),
(7,'Business Loan',2000000,24,'Working Capital','3000000007','PENDING',NULL,NULL,NULL),
(8,'Education Loan',600000,18,'Professional Certification','3000000008','APPROVED',2,'Approved after verification','2026-05-08 16:00:00'),
(9,'Personal Loan',350000,12,'Emergency Needs','3000000009','REJECTED',2,'Previous delinquency identified','2026-05-09 17:00:00'),
(10,'Business Loan',3000000,36,'Business Expansion','3000000010','PENDING',NULL,NULL,NULL);

/*=================VALIDATION QUERY=================

Purpose:
Verify that all loan request records
were successfully loaded.

Expected Result:
10 records

===================================================*/

SELECT
'ib_loan_requests' AS table_name,
COUNT(*) AS total_records
FROM ib_loan_requests;

/*=================DML - NOTIFICATIONS=================

Purpose:
Populate customer notification records generated
by Internet Banking activities.

The dataset includes transaction alerts,
security notifications, bill payment confirmations,
and loan application updates delivered through
different communication channels.

==============================================================*/

INSERT INTO ib_notifications
(
user_id,
notif_type,
channel,
message,
is_read,
related_txn_ref
)
VALUES

(1,'TRANSFER','EMAIL','Your transfer TXN000001 was successfully processed.',1,'TXN000001'),
(2,'TRANSFER','SMS','Your transfer TXN000002 was successfully processed.',1,'TXN000002'),
(3,'TRANSFER','EMAIL','Your transfer TXN000003 was successfully processed.',1,'TXN000003'),
(4,'TRANSFER','SMS','Transfer TXN000004 failed due to OTP expiration.',1,'TXN000004'),
(5,'BILL_PAYMENT','EMAIL','Bill payment BILL000005 completed successfully.',1,'BILL000005'),

(6,'LOGIN_ALERT','SMS','New login detected from Ibadan.',0,NULL),
(7,'TRANSFER','EMAIL','Transfer TXN000007 failed due to OTP verification failure.',1,'TXN000007'),
(8,'LOGIN_ALERT','EMAIL','New login detected from Lagos.',0,NULL),
(9,'TRANSFER','SMS','Transfer TXN000009 failed due to OTP expiration.',1,'TXN000009'),
(10,'LOAN_UPDATE','EMAIL','Your loan application is under review.',0,NULL),

(11,'TRANSFER','EMAIL','Your transfer TXN000011 was successfully processed.',1,'TXN000011'),
(12,'TRANSFER','SMS','Your transfer TXN000012 was successfully processed.',1,'TXN000012'),
(13,'BILL_PAYMENT','EMAIL','Bill payment BILL000013 failed due to network issues.',1,'BILL000013'),
(14,'TRANSFER','SMS','Your transfer TXN000014 was successfully processed.',1,'TXN000014'),
(15,'LOAN_UPDATE','EMAIL','Your loan request has been approved.',1,NULL),

(16,'SECURITY','SMS','Password change completed successfully.',1,NULL),
(17,'TRANSFER','EMAIL','Your transfer TXN000017 was successfully processed.',1,'TXN000017'),
(18,'TRANSFER','SMS','Your transfer TXN000018 was successfully processed.',1,'TXN000018'),
(19,'SECURITY','EMAIL','Multiple login attempts detected on your account.',0,NULL),
(20,'TRANSFER','SMS','Your transfer TXN000020 was successfully processed.',1,'TXN000020');

/*=================VALIDATION QUERY=================

Purpose:
Verify that all notification records
were successfully loaded.

Expected Result:
20 records

===================================================*/
SELECT
'ib_notifications' AS table_name,
COUNT(*) AS total_records
FROM ib_notifications;

/*=================DML - AUDIT LOGS=================

Purpose:
Populate audit trail records used to monitor
administrative actions performed within the
Internet Banking platform.

The dataset includes account maintenance,
status changes, security actions, and customer
profile updates executed by bank administrators.

==============================================================*/

INSERT INTO ib_audit_logs
(
table_name,
operation,
record_id,
performed_by,
user_affected,
old_values,
new_values,
ip_address
)
VALUES

('ib_users','UPDATE','1',1,1,'ACTIVE','LOCKED','10.10.1.1'),
('ib_users','UPDATE','2',1,2,'LOCKED','ACTIVE','10.10.1.1'),
('ib_users','UPDATE','3',2,3,'DORMANT','ACTIVE','10.10.1.2'),
('ib_users','UPDATE','4',2,4,'ACTIVE','SUSPENDED','10.10.1.2'),
('ib_users','UPDATE','5',3,5,'ACTIVE','LOCKED','10.10.1.3'),

('ib_limit_definitions','UPDATE','6',3,6,'500000','1000000','10.10.1.3'),
('ib_limit_definitions','UPDATE','7',4,7,'1000000','2000000','10.10.1.4'),
('ib_limit_definitions','UPDATE','8',4,8,'200000','500000','10.10.1.4'),
('ib_sessions','DELETE','9',5,9,'ACTIVE SESSION','SESSION CLOSED','10.10.1.5'),
('ib_sessions','DELETE','10',5,10,'ACTIVE SESSION','SESSION CLOSED','10.10.1.5'),

('ib_beneficiaries','INSERT','11',1,11,NULL,'NEW BENEFICIARY','10.10.1.1'),
('ib_beneficiaries','INSERT','12',1,12,NULL,'NEW BENEFICIARY','10.10.1.1'),
('ib_transfers','UPDATE','13',2,13,'PENDING','SUCCESS','10.10.1.2'),
('ib_transfers','UPDATE','14',2,14,'PENDING','FAILED','10.10.1.2'),
('ib_bill_payments','UPDATE','15',3,15,'PENDING','SUCCESS','10.10.1.3'),

('ib_loan_requests','UPDATE','16',4,16,'PENDING','APPROVED','10.10.1.4'),
('ib_loan_requests','UPDATE','17',4,17,'PENDING','REJECTED','10.10.1.4'),
('ib_notifications','UPDATE','18',5,18,'UNREAD','READ','10.10.1.5'),
('ib_notifications','UPDATE','19',5,19,'UNREAD','READ','10.10.1.5'),
('ib_users','UPDATE','20',1,20,'ACTIVE','ACTIVE + MFA ENABLED','10.10.1.1');

/*=================VALIDATION QUERY=================

Purpose:
Verify that all audit log records
were successfully loaded.

Expected Result:
20 records

===================================================*/
SELECT
'ib_audit_logs' AS table_name,
COUNT(*) AS total_records
FROM ib_audit_logs;


/*=================UPDATE OPERATION - JSON UPDATE=================

Purpose:
Demonstrate updating attributes stored inside
a JSON document using JSON_SET().

The session metadata will be enriched with
additional security information required for
customer activity monitoring.

==============================================================*/

SELECT
session_id,
session_meta
FROM ib_sessions
WHERE session_id = 1;

UPDATE ib_sessions
SET session_meta =
JSON_SET(
    session_meta,
    '$.risk_level', 'LOW',
    '$.authentication_method', 'PASSWORD+OTP'
)
WHERE session_id = 1;

/*=================VALIDATION QUERY=================

Purpose:
Verify that JSON attributes were successfully
added to the session metadata.

Expected Result:
JSON document containing risk_level and
authentication_method attributes.

===================================================*/
SELECT
session_id,
session_meta
FROM ib_sessions
WHERE session_id = 1;


/*=================UPDATE OPERATION - XML UPDATE=================

Purpose:
Demonstrate updating XML content stored
inside a TEXT field using string manipulation.

The bill payment response will be converted
from plain text into a structured XML format.

==============================================================*/

SELECT
bill_id,
biller_name,
biller_response
FROM ib_bill_payments
WHERE bill_id = 1;

UPDATE ib_bill_payments
SET biller_response =
REPLACE(
    biller_response,
    '<provider>IKEDC</provider>',
    '<provider>IKEJA_ELECTRIC</provider>'
)
WHERE bill_id = 1;

/*=================VALIDATION QUERY=================

Purpose:
Verify that XML content stored in a TEXT field
was successfully updated using string manipulation.

Expected Result:
XML document containing provider
IKEJA_ELECTRIC.

===================================================*/
SELECT
bill_id,
biller_response
FROM ib_bill_payments
WHERE bill_id = 1;


/*=================DELETE OPERATION=================

Purpose:
Demonstrate removal of records using
the DELETE statement.

A notification record will be removed
from the Internet Banking platform and
the result will be validated.

==============================================================*/
SELECT
'ib_notifications' AS table_name,
COUNT(*) AS total_records
FROM ib_notifications;

SELECT
notification_id,
user_id,
notif_type
FROM ib_notifications
WHERE notification_id = 20;

DELETE
FROM ib_notifications
WHERE notification_id = 20;

/*=================VALIDATION QUERY=================

Purpose:
Verify that the notification record
was successfully deleted.

Expected Result:
19 records

===================================================*/
SELECT
'ib_notifications' AS table_name,
COUNT(*) AS total_records
FROM ib_notifications;


/*=================REFERENTIAL INTEGRITY VALIDATION=================

Purpose:
Verify that related tables are properly linked
through foreign key relationships.

This validation confirms that user records
are correctly associated with session records.

==============================================================*/

SELECT
u.user_id,
u.username,
s.session_id,
s.login_time
FROM ib_users u
INNER JOIN ib_sessions s
ON u.user_id = s.user_id
LIMIT 10;

/*=================JSON AND XML VALIDATION=================

Purpose:
Verify that JSON and XML updates were
successfully applied.

This validation demonstrates support for
semi-structured and text-based data updates.

==============================================================*/

SELECT
'JSON Validation' AS validation_type,
session_meta AS validation_result
FROM ib_sessions
WHERE session_id = 1

UNION ALL

SELECT
'XML Validation' AS validation_type,
biller_response AS validation_result
FROM ib_bill_payments
WHERE bill_id = 1;

/*=================ANALYTICS READINESS VALIDATION=================

Purpose:
Verify that transactional data is complete,
consistent, and ready for downstream analytics
and machine learning activities.

This validation demonstrates that transaction
records can be aggregated and analyzed for
business intelligence reporting.

==============================================================*/
SELECT
status,
COUNT(*) AS total_transfers,
SUM(amount) AS total_amount
FROM ib_transfers
GROUP BY status;

-- =============================================================================
--    --------------- DATA QUERY LANGUAGE (DQL)--------------
-- =============================================================================
-- QUERY 1: MULTI-CHANNEL FRAUD DETECTION VIA TELEMETRY & VELOCITY ANOMALIES
-- 
-- • Analytical/Business Question:
--   Which users are demonstrating suspicious session access patterns across distinct 
--   device types, browser channels, or geographic locations within narrow time windows?
-- 
-- • Role of Database Components:
--   - JOINS: Marries 'ib_sessions' to 'ib_users' to link metadata to real identities.
--   - SEMI-STRUCTURED DATA ACCESS: Uses native 'JSON_UNQUOTE' and 'JSON_EXTRACT' 
--     to unpack nested tracking components ('device', 'browser', 'location') out of 'session_meta'.
--   - WINDOW FUNCTIONS: Employs 'LAG()' partitioned by user_id to compute concurrent 
--     temporal gaps and infrastructure shifts between sequential logins.
-- 
-- • Analytics/Machine Learning Suitability:
--   Serves as a high-value feature extraction engine for training an unsupervised 
--   Isolation Forest model to trigger real-time multi-factor authentication locks.
-- -----------------------------------------------------------------------------
SELECT 
    s.session_id,
    s.user_id,
    u.username,
    s.ip_address AS current_ip,
    s.login_time AS current_login_time,
    JSON_UNQUOTE(JSON_EXTRACT(s.session_meta, '$.device')) AS current_device,
    JSON_UNQUOTE(JSON_EXTRACT(s.session_meta, '$.browser')) AS current_browser,
    JSON_UNQUOTE(JSON_EXTRACT(s.session_meta, '$.location')) AS current_location,
    
    -- Windowing to fetch immediate prior session context variables
    LAG(s.ip_address, 1) OVER (PARTITION BY s.user_id ORDER BY s.login_time) AS prior_ip,
    LAG(JSON_UNQUOTE(JSON_EXTRACT(s.session_meta, '$.device')), 1) 
        OVER (PARTITION BY s.user_id ORDER BY s.login_time) AS prior_device,
    LAG(JSON_UNQUOTE(JSON_EXTRACT(s.session_meta, '$.location')), 1) 
        OVER (PARTITION BY s.user_id ORDER BY s.login_time) AS prior_location,
        
    -- Compute real-time login velocity lapse metric
    TIMESTAMPDIFF(MINUTE, LAG(s.login_time, 1) OVER (PARTITION BY s.user_id ORDER BY s.login_time), s.login_time) AS velocity_lapse_minutes
FROM ib_sessions s
JOIN ib_users u ON s.user_id = u.user_id
ORDER BY s.user_id, s.login_time DESC;


-- -----------------------------------------------------------------------------
-- QUERY 2: GATEWAY SERVICES XML MINING & DEFICIT RECONCILIATION PIPELINE
-- -----------------------------------------------------------------------------
-- • Analytical/Business Question:
--   What specific raw backend exceptions are our utility clearings encountering 
--   within the 'biller_response' records, and how much financial volume is blocked?
-- 
-- • Role of Database Components:
--   - JOINS: Maps billing records to user structures to identify customer profiles.
--   - GROUP BY & AGGREGATION: Aggregates successful versus failed payment totals 
--     using conditional SUM operations across provider groups.
--   - XML PARSING: Employs 'EXTRACTVALUE()' to extract nested data points from 
--     the 'biller_response' XML-TEXT column (e.g., status and error attributes).
-- 
-- • Analytics/Machine Learning Suitability:
--   Provides operational error categorization vectors, serving as optimal label indicators
--   to track vendor up-time dependencies and infrastructure degradations.
-- -----------------------------------------------------------------------------
SELECT 
    bp.biller_name,
    COUNT(bp.bill_id) AS total_payment_attempts,
    SUM(bp.amount) AS gross_attempted_volume_naira,
    
    -- Summing valid vs failed allocations via conditional extraction blocks
    SUM(CASE WHEN bp.status = 'SUCCESS' THEN bp.amount ELSE 0 END) AS successful_settled_volume,
    SUM(CASE WHEN bp.status = 'FAILED' THEN bp.amount ELSE 0 END) AS failed_deficit_volume,
    
    -- Extracting nested nodes directly from your XML schema text field
    EXTRACTVALUE(bp.biller_response, '/response/status') AS extracted_xml_status,
    EXTRACTVALUE(bp.biller_response, '/response/provider') AS extracted_xml_provider,
    
    ROUND((SUM(CASE WHEN bp.status = 'FAILED' THEN 1 ELSE 0 END) / COUNT(bp.bill_id)) * 100, 2) AS failure_rate_percentage
FROM ib_bill_payments bp
GROUP BY bp.biller_name, EXTRACTVALUE(bp.biller_response, '/response/status'), EXTRACTVALUE(bp.biller_response, '/response/provider')
ORDER BY failed_deficit_volume DESC;


-- -----------------------------------------------------------------------------
-- QUERY 3: ADMINISTRATIVE RISK SCREENING & COMPLIANCE AUDIT ENGINE 
-- -----------------------------------------------------------------------------
-- • Analytical/Business Question:
--   Which operational administrative personnel are manually executing table-level 
--   modifications or system status overrides, what are their underlying derived 
--   privilege clearance hierarchies, and what is the exact before-and-after trace 
--   blueprint of data alterations affecting our digital banking customers?
-- 
-- • Role of Database Components:
--   - MULTI-TABLE JOINS: Deeply integrates 'ib_audit_logs' with 'ib_admin_users' 
--     and 'ib_users' to construct an unbroken chain of custody (Actor -> Action -> Target).
--   - REGULATORY CORRELATED SUBQUERY: Evaluates authorization thresholds by executing 
--     an isolated inner 'SELECT' loop that intersects the admin's unique identifier.
--   - SEMI-STRUCTURED JSON DATA ACCESS: Uses native 'JSON_EXTRACT' to scan the flat 
--     boolean object parameters ('manage_limits', 'approve_loans', 'reset_passwords') 
--     to verify operational access controls without costly schema expansions.
--   - STRING PATTERN MINING: Employs conditional 'LIKE' filtering blocks to parse 
--     and filter cleartext transactional log columns for high-risk corporate 
--     security terminology ('OVERRIDE', 'SUSPEND', 'ACTIVE').
-- 
-- • Analytics/Machine Learning Suitability:
--   Transforms highly messy, unstructured system audit trails and complex JSON data 
--   blobs into an engineered, structured numeric data grid. By mapping text into 
--   standardized categorical scales (3, 2, 1, 0) and binary feature vectors (1 or 0), 
--   the output is directly ingestible by classification or anomaly detection algorithms 
--   (such as Random Forests, XGBoost, or Isolation Forests) to model inside threat 
--   vulnerabilities and flag unauthorized privilege escalations automatically.
-- -----------------------------------------------------------------------------

SELECT 
    al.log_id,
    al.changed_at,
    al.table_name,
    al.operation,
    al.record_id,
    CONCAT(au.first_name, ' ', au.last_name) AS administrative_actor_identity,
    au.role AS admin_functional_role,
    
    -- 1. REGULATORY SUBQUERY: Evaluates authorization thresholds via an explicit inner query layout
    (SELECT 
        CASE 
            WHEN JSON_EXTRACT(sub_au.permissions, '$.manage_limits') = true THEN 3
            WHEN JSON_EXTRACT(sub_au.permissions, '$.approve_loans') = true THEN 2
            WHEN JSON_EXTRACT(sub_au.permissions, '$.reset_passwords') = true THEN 1
            ELSE 0 
        END
     FROM ib_admin_users sub_au 
     WHERE sub_au.admin_id = au.admin_id) AS administrative_clearance_numeric_tier,
    
    -- 2. ANALYTICAL/ML READINESS: Transforms categorical text into clean numeric binary targets (1 or 0)
    CASE WHEN JSON_EXTRACT(au.permissions, '$.manage_limits') = true THEN 1 ELSE 0 END AS feature_holds_limit_override_power,
    CASE WHEN JSON_EXTRACT(au.permissions, '$.approve_loans') = true THEN 1 ELSE 0 END AS feature_holds_credit_signing_power,
    
    CONCAT(u.username, ' (ID: ', al.user_affected, ')') AS affected_customer_profile,
    al.old_values AS cleartext_previous_state,
    al.new_values AS cleartext_updated_state
FROM ib_audit_logs al
JOIN ib_admin_users au ON al.performed_by = au.admin_id
LEFT JOIN ib_users u ON al.user_affected = u.user_id
WHERE al.operation IN ('INSERT', 'UPDATE', 'DELETE')
  AND (al.new_values LIKE '%OVERRIDE%' OR al.new_values LIKE '%SUSPEND%' OR al.old_values LIKE '%ACTIVE%')
ORDER BY al.changed_at DESC;

-- -----------------------------------------------------------------------------
-- QUERY 4: TRANSACTION FAILURE RADAR & CORE API SYSTEM LATENCY
-- -----------------------------------------------------------------------------
-- • Analytical/Business Question:
--   Which corporate or retail accounts are experiencing repeated transfer transaction 
--   failures, and what percentage of their total outbound funds are getting trapped? 
--   (Crucial for tracking system stability and preventing high-value customer churn).
-- 
-- • Role of Database Components:
--   - GROUP BY & AGGREGATION: Aggregates total transfer volume, total successful volume, 
--     and total failed volume per customer.
--   - CASE WHEN STATEMENTS: Dynamically handles the sum of transaction statuses 
--     ('SUCCESS' vs 'FAILED') without requiring complex self-joins.
-- 
-- • Analytics/ML Readiness:
--   Provides explicit failure-rate matrices per user profile, serving as high-value 
--   input variables for automated Customer Satisfaction (CSAT) forecasting.
-- -----------------------------------------------------------------------------
SELECT 
    t.user_id,
    u.username,
    lp.profile_name AS limit_tier,
    COUNT(t.transfer_id) AS total_transfer_attempts,
    
    -- Categorize transaction volume success vs failure boundaries
    SUM(CASE WHEN t.status = 'SUCCESS' THEN t.amount ELSE 0.00 END) AS net_successful_capital_naira,
    SUM(CASE WHEN t.status = 'FAILED' THEN t.amount ELSE 0.00 END) AS net_trapped_failed_capital_naira,
    
    -- Compute percentage value of transaction failure rate
    ROUND((COUNT(CASE WHEN t.status = 'FAILED' THEN 1 END) / COUNT(t.transfer_id)) * 100, 2) AS single_customer_failure_rate_percentage
FROM ib_transfers t
JOIN ib_users u ON t.user_id = u.user_id
JOIN ib_limit_profiles lp ON u.profile_id = lp.profile_id
GROUP BY t.user_id, u.username, lp.profile_name
HAVING net_trapped_failed_capital_naira > 0
ORDER BY net_trapped_failed_capital_naira DESC;

-- =============================================================================
-- MACHINE LEARNING DATASET FEATURE ENGINEERING PIPELINES
-- =============================================================================
-- DATASET A: STAFF AUTOMATION INEFFICIENCY RADAR (CLASSIFICATION APPLICATION)
-- -----------------------------------------------------------------------------
-- • Analytical/Business Question Answered:
--   Are our customer account tiers suffering from operational inefficiencies caused by 
--   excessive manual staff maintenance, and can we identify a correlation between 
--   historical admin updates and accounts that ultimately fall into restricted, 
--   risk-flagged states (Locked or Suspended)?
-- 
-- • Role of Database Components:
--   - BASE SELECTION: Extracts the root digital identities from the master user registry ('ib_users').
--   - CORRELATED SCALAR SUBQUERY: Dynamically queries the 'ib_audit_logs' table for each 
--     individual user row, isolating and counting records where 'al.operation = UPDATE' to 
--     measure the exact historical workload footprint imposed on bank personnel.
--   - CONDITIONAL LOGICAL EXPRESSION: Deploys a 'CASE WHEN' statement to map the current state 
--     ('status_id') into a clean binary classification indicator without requiring additional 
--     table lookup joins.
-- 
-- • Analytics/Machine Learning Suitability:
--   - OPERATIONAL BUSINESS ANALYTICS: Isolates continuous and categorical fields, allowing analysts 
--     to group accounts by limit tier ('operational_limit_tier') to calculate the mean volume of 
--     manual staff fixes required per customer segment.
--   - MACHINE LEARNING INTEGRITY: By avoiding sparse, null-heavy tracking columns (such as 
--     historical login parameters), this data grid delivers a completely clean, non-sparse matrix. 
--     The features map out independent historical activity ('total_manual_staff_adjustments') against 
--     a distinct binary label (**'Target_Profile_Requires_Intervention' = 1 or 0**). This structure 
--     is optimized to train supervised classification models (such as **Logistic Regression** or 
--     **Random Forest Classifiers**) to proactively predict which user profiles will experience future 
--     system friction and require administrative support.
--
-- Purpose: Builds an operational training matrix to predict profile locking risks.
-- =============================================================================
SELECT 
    u.user_id,
    u.profile_id AS operational_limit_tier,
    
    -- Count the exact amount of historical manual entries logged by the bank staff
    (SELECT COUNT(*) FROM ib_audit_logs al 
     WHERE al.user_affected = u.user_id AND al.operation = 'UPDATE') AS total_manual_staff_adjustments,
     
    -- Target Label: Predicts if the account will end up in a compromised state (Locked/Suspended = 1, Active = 0)
    CASE WHEN u.status_id IN (2, 3) THEN 1 ELSE 0 END AS Target_Profile_Requires_Intervention
FROM ib_users u;

-- =============================================================================
-- DATASET B: ORGANIZATIONAL PERFORMANCE / VENDOR SLA MONITORING
-- -----------------------------------------------------------------------------
-- • Analytical/Business Question Answered:
--   Which third-party billing aggregators and utility merchants are violating their
--   contractual Service Level Agreements (SLAs) by demonstrating high payment 
--   failure rates, and what is the exact revenue volume locked behind these unstable APIs?
-- 
-- • Role of Database Components:
--   - AGGREGATION & GROUPING: Bundles transactional rows by 'biller_code' and 'biller_name' 
--     to compute cumulative pipeline performance metrics.
--   - CONDITIONAL SUM PATTERNS: Utilizes 'SUM(CASE WHEN...)' blocks to dynamically split 
--     and count successful vs. failed records without collapsing row-level data.
--   - REGULATORY STRING MINING: Evaluates cleartext data columns to calculate structural 
--     ratios directly from transaction ledger entries.
-- 
-- • Analytics/Machine Learning Suitability:
--   - KPI DASHBOARD INTEGRATION: Compiles success rate percentages and average ticket 
--     sizes, making it perfect for real-time executive operations dashboards (e.g., PowerBI).
--   - DOWNSTREAM REGRESSION DATASET: Serves as a clean continuous variable training matrix 
--     to predict total fee leakage based on a vendor's historical processing success rates.
-- =============================================================================
SELECT 
    bp.biller_code,
    bp.biller_name,
    COUNT(bp.bill_id) AS total_payment_attempts,
    
    -- Count distinct transaction states using conditional summation
    SUM(CASE WHEN bp.status = 'SUCCESS' THEN 1 ELSE 0 END) AS successful_payments_count,
    SUM(CASE WHEN bp.status = 'FAILED' THEN 1 ELSE 0 END) AS failed_payments_count,
    
    -- Dynamically calculate the processing success rate percentage
    ROUND(
        (SUM(CASE WHEN bp.status = 'SUCCESS' THEN 1 ELSE 0 END) / COUNT(bp.bill_id)) * 100, 
        2
    ) AS processing_success_rate_percentage,
    
    -- Aggregate financial parameters mapping the biller's processing volume
    SUM(bp.amount) AS total_revenue_processed_value,
    ROUND(AVG(bp.amount), 2) AS average_ticket_size
FROM ib_bill_payments bp
GROUP BY bp.biller_code, bp.biller_name
ORDER BY processing_success_rate_percentage ASC, total_revenue_processed_value DESC;

-- =============================================================================
-- DATASET C - DIGITAL PLATFORM PERSONALIZATION MATRIX: CROSS-CHANNEL COMPONENT SEGMENTATION
-- APPLICATION: UNSUPERVISED MACHINE LEARNING (K-MEANS FEATURE VECTOR ENGINE)
-- -----------------------------------------------------------------------------
-- • Analytical/Business Question Answered:
--   What are the cross-channel transaction preferences and digital platform 
--   engagement signatures across our customer portfolio, and how effectively 
--   do different user cohorts convert portal login traffic into successful, 
--   revenue-generating transfers and utility bill payments?
-- 
-- • Role of Database Components:
--   - MULTI-TABLE LEFT JOINS: Connects the core identity registry ('ib_users') 
--     with session histories ('ib_sessions'), funds transfers ('ib_transfers'), 
--     and billing collections ('ib_bill_payments') without dropping inactive users.
--   - CONDITIONAL AGGREGATION PATTERNS: Utilizes 'COUNT(DISTINCT CASE WHEN...)' 
--     to parse device strings embedded in the 'session_meta' column, splitting 
--     traffic into separate mobile vs. desktop frequency metrics.
--   - ZERO-DIVISOR PROTECTION RULES: Combines 'COALESCE()' and 'NULLIF()' functions 
--     to handle the mathematical denominator when building behavioral ratios. This 
--     safely prevents division-by-zero database engine crashes for accounts with zero transactions.
-- 
-- • Analytics/Machine Learning Suitability:
--   - DESCRIPTIVE CONVERSION ANALYTICS: Computes transaction-per-session ratios 
--     and product affinity matrices, allowing analysts to run descriptive checks 
--     and isolate low-engagement app traffic from heavy power users.
--   - VECTOR ENGINE STRUCTURE: Builds a flat data matrix with exactly one row per 
--     customer ID. Every field outputs a clean, continuous numerical metric, completely 
--     eliminating blank slots or text strings. This structure is perfectly optimized 
--     to train an unsupervised **K-Means Clustering** or **Hierarchical Clustering** 
--     algorithm in Python, enabling the business to dynamically segment users into 
--     custom behavioral personas (e.g., Mobile Power Billers vs. Desktop Transferrer Lines) 
--     and design tailored mobile app user experiences.
-- =============================================================================

WITH session_summary AS (
    SELECT 
        user_id,
        COUNT(session_id) AS analytical_cumulative_login_sessions,
        SUM(CASE WHEN session_meta LIKE '%Mobile%' THEN 1 ELSE 0 END) AS mobile_app_session_count,
        SUM(CASE WHEN session_meta LIKE '%Desktop%' THEN 1 ELSE 0 END) AS web_portal_session_count
    FROM ib_sessions
    GROUP BY user_id
),
transfer_summary AS (
    SELECT 
        user_id,
        COUNT(transfer_id) AS aggregate_successful_transfers
    FROM ib_transfers
    WHERE status = 'SUCCESS'
    GROUP BY user_id
),
billing_summary AS (
    SELECT 
        user_id,
        COUNT(bill_id) AS aggregate_successful_bill_payments
    FROM ib_bill_payments
    WHERE status = 'SUCCESS'
    GROUP BY user_id
)
SELECT 
    u.user_id,
    u.username,
    
    -- Feature Group 1: Raw Channel Telemetry Metrics
    COALESCE(ss.analytical_cumulative_login_sessions, 0) AS analytical_cumulative_login_sessions,
    COALESCE(ss.mobile_app_session_count, 0) AS mobile_app_session_count,
    COALESCE(ss.web_portal_session_count, 0) AS web_portal_session_count,
    
    -- Feature Group 2: Core Outflow Transaction Counts
    COALESCE(ts.aggregate_successful_transfers, 0) AS aggregate_successful_transfers,
    COALESCE(bps.aggregate_successful_bill_payments, 0) AS aggregate_successful_bill_payments,
    
    -- Feature Group 3: Structuring Core Operational Behavioral Ratios
    ROUND(
        COALESCE(bps.aggregate_successful_bill_payments, 0) / 
        NULLIF(COALESCE(ts.aggregate_successful_transfers, 0) + COALESCE(bps.aggregate_successful_bill_payments, 0), 0), 
        4
    ) AS utility_bill_to_transfer_ratio
FROM ib_users u
LEFT JOIN session_summary ss ON u.user_id = ss.user_id
LEFT JOIN transfer_summary ts ON u.user_id = ts.user_id
LEFT JOIN billing_summary bps ON u.user_id = bps.user_id;




