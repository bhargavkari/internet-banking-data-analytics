USE internet_banking;

/* DATA ANALYST QUERY PACK
   Run after 01_database_setup.sql. These queries use the project's existing tables.
*/

-- 1. Overall bill-payment KPIs
SELECT
    COUNT(*) AS total_payment_attempts,
    SUM(status = 'SUCCESS') AS successful_payments,
    SUM(status = 'FAILED') AS failed_payments,
    ROUND(100.0 * SUM(status = 'SUCCESS') / NULLIF(COUNT(*), 0), 2) AS success_rate_pct,
    ROUND(SUM(CASE WHEN status = 'SUCCESS' THEN amount ELSE 0 END), 2) AS successful_payment_value,
    ROUND(AVG(CASE WHEN status = 'SUCCESS' THEN amount END), 2) AS avg_successful_payment
FROM ib_bill_payments;

-- 2. Biller performance and revenue (failed transactions excluded from revenue)
SELECT biller_code, biller_name,
       COUNT(*) AS attempts,
       SUM(status = 'SUCCESS') AS successes,
       SUM(status = 'FAILED') AS failures,
       ROUND(100.0 * SUM(status = 'SUCCESS') / NULLIF(COUNT(*), 0), 2) AS success_rate_pct,
       ROUND(SUM(CASE WHEN status = 'SUCCESS' THEN amount ELSE 0 END), 2) AS successful_revenue
FROM ib_bill_payments
GROUP BY biller_code, biller_name
ORDER BY successful_revenue DESC;

-- 3. Monthly bill-payment trend
SELECT DATE_FORMAT(initiated_time, '%Y-%m') AS payment_month,
       COUNT(*) AS payment_attempts,
       SUM(status = 'SUCCESS') AS successful_payments,
       ROUND(SUM(CASE WHEN status = 'SUCCESS' THEN amount ELSE 0 END), 2) AS successful_value
FROM ib_bill_payments
GROUP BY DATE_FORMAT(initiated_time, '%Y-%m')
ORDER BY payment_month;

-- 4. Transfer status summary
SELECT status, COUNT(*) AS transfer_count,
       ROUND(SUM(amount), 2) AS transfer_value,
       ROUND(AVG(amount), 2) AS average_transfer
FROM ib_transfers
GROUP BY status
ORDER BY transfer_count DESC;

-- 5. Customer activity by account status
SELECT s.status_name, COUNT(*) AS customer_count
FROM ib_users u
JOIN ib_user_status s ON s.status_id = u.status_id
GROUP BY s.status_name
ORDER BY customer_count DESC;

-- 6. Customer-level activity: successful transfers and bill payments
WITH transfer_kpi AS (
    SELECT user_id, COUNT(*) AS successful_transfers,
           SUM(amount) AS transfer_value
    FROM ib_transfers WHERE status = 'SUCCESS' GROUP BY user_id
), bill_kpi AS (
    SELECT user_id, COUNT(*) AS successful_bill_payments,
           SUM(amount) AS bill_payment_value
    FROM ib_bill_payments WHERE status = 'SUCCESS' GROUP BY user_id
)
SELECT u.user_id, u.username,
       COALESCE(t.successful_transfers, 0) AS successful_transfers,
       COALESCE(t.transfer_value, 0) AS transfer_value,
       COALESCE(b.successful_bill_payments, 0) AS successful_bill_payments,
       COALESCE(b.bill_payment_value, 0) AS bill_payment_value
FROM ib_users u
LEFT JOIN transfer_kpi t ON t.user_id = u.user_id
LEFT JOIN bill_kpi b ON b.user_id = u.user_id
ORDER BY (COALESCE(t.transfer_value, 0) + COALESCE(b.bill_payment_value, 0)) DESC;

-- 7. Loan request pipeline
SELECT status, COUNT(*) AS request_count,
       ROUND(SUM(requested_amount), 2) AS requested_amount_total,
       ROUND(AVG(requested_amount), 2) AS average_request_amount
FROM ib_loan_requests
GROUP BY status
ORDER BY request_count DESC;

-- 8. Monthly loan demand
SELECT DATE_FORMAT(submitted_time, '%Y-%m') AS request_month,
       COUNT(*) AS loan_requests,
       ROUND(SUM(requested_amount), 2) AS total_requested_amount
FROM ib_loan_requests
GROUP BY DATE_FORMAT(submitted_time, '%Y-%m')
ORDER BY request_month;

-- 9. Session activity by device/channel metadata
SELECT
    CASE
      WHEN session_meta LIKE '%Mobile%' THEN 'Mobile'
      WHEN session_meta LIKE '%Desktop%' THEN 'Desktop'
      ELSE 'Other / Not specified'
    END AS access_channel,
    COUNT(*) AS session_count,
    COUNT(DISTINCT user_id) AS unique_users
FROM ib_sessions
GROUP BY access_channel
ORDER BY session_count DESC;

-- 10. Users requiring re-engagement (never logged in or inactive >= 30 days)
SELECT user_id, username, email, last_login,
       CASE
         WHEN last_login IS NULL THEN 'Never logged in'
         WHEN DATEDIFF(CURRENT_DATE, last_login) BETWEEN 30 AND 90 THEN 'Inactive 30-90 days'
         ELSE 'Inactive over 90 days'
       END AS engagement_segment
FROM ib_users
WHERE last_login IS NULL OR DATEDIFF(CURRENT_DATE, last_login) >= 30
ORDER BY last_login;

-- 11. Daily payment trend for dashboard date slicers
SELECT DATE(initiated_time) AS payment_date,
       COUNT(*) AS attempts,
       SUM(status = 'SUCCESS') AS successes,
       ROUND(SUM(CASE WHEN status = 'SUCCESS' THEN amount ELSE 0 END), 2) AS successful_value
FROM ib_bill_payments
GROUP BY DATE(initiated_time)
ORDER BY payment_date;

-- 12. Data-quality check: missing or invalid bill-payment fields
SELECT
    SUM(biller_code IS NULL OR TRIM(biller_code) = '') AS missing_biller_code,
    SUM(biller_name IS NULL OR TRIM(biller_name) = '') AS missing_biller_name,
    SUM(amount IS NULL OR amount <= 0) AS invalid_amount,
    SUM(status IS NULL OR TRIM(status) = '') AS missing_status
FROM ib_bill_payments;
